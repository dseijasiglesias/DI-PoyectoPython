import SeijasAcademy.main

SeijasAcademy.main.__init__.py